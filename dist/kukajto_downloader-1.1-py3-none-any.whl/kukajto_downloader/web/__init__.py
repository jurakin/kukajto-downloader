from .__main__ import main

__all__ = [
    "main",
]

__version__ = "1.1"