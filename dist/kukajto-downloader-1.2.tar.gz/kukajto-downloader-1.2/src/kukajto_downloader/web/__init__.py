from .__main__ import main
from .. import __version__

__all__ = [
    "main",
]

__version__ = __version__